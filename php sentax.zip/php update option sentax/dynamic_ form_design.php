<?php
include_once 'db/conn.php';
require_once 'db/sequre_page.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title>Enquery input form</title>
    <!-- GLOBAL MAINLY STYLES-->
    <link href="./assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="./assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="./assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="./assets/vendors/jvectormap/jquery-jvectormap-2.0.3.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="assets/css/main.min.css" rel="stylesheet" />
    <link href="assets/css/dashboard.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
    <style>
      td {
         width:50%;
         align-items: center;
      }
   </style>
    <script language="javascript">
                function current_date(){
            document.getElementById("date").valueAsDate = new Date();
                }
            
        function myFunction() {
        
            if (confirm("Are you sure to delete?") == true) {
            
            
        return true;
                
            } else {
                return false;
                
            }
            
        }



        function convert_data_to_upper(x)
            {
                
                x.value=x.value.toUpperCase();
            }
 
 
        function check_numeric(x)
        {
      
            var str="0123456789";
            i=0;
            
            while(i<x.value.length)
                {
                    //alert(x.value);
                    if(str.indexOf(x.value.charAt(i))==-1)
                        {
                        x.value=x.value.substring(0,i);
                        return false;
                        }
                    
                    i++;
                }
	 
            }
 
 
 
 
 
 
            function check_decimal(x)
            {
                
                var str="0123456789.";
                i=0;
                number_of_decimal_point=0;
                while(i<x.value.length)
                    {
                        //alert(x.value);
                        if(str.indexOf(x.value.charAt(i))==-1)
                            {
                            x.value=x.value.substring(0,i);
                            return false;
                            }
                        if(".".indexOf(x.value.charAt(i))!=-1)
                            {
                            number_of_decimal_point++;
                            if(number_of_decimal_point>1)
                                {
                                x.value=x.value.substring(0,i);
                                return false;
                                }
                            }
                        i++;
                    }
                
            }
            function set_data(x)
            {
                var client_id=x.value;
                var enq_subject=document.getElementById("enq_subject").value;
                var enq_no=document.getElementById("enq_no").value;   
                window.location.href = "enquery_input_form.php?client_id="+client_id+"&enq_subject="+enq_subject+"&enq_no="+enq_no;
            }

            function validate()
            {
                
                var item_count=document.getElementById("item_count").value;
                //alert(item_count);
                var i=0;
                var flag=0;
                while(i*1<item_count*1)
                {
                    //`id`, `enq_id`, `item_id`, `description`, `qty_unit`, `qty_requirement`SELECT * FROM `enq_item_details` WHERE 1
                    
                    i++;
                    var item_id=document.getElementById("item_id"+i).value;
                    var description=document.getElementById("description"+i).value;
                    var qty_unit=document.getElementById("qty_unit"+i).value;
                    var qty_requirement=document.getElementById("qty_requirement"+i).value;
                    if(item_id!="" & description!="" & qty_unit!="" & qty_requirement!="")
                    { 
                        flag++;
                        return true;
                        
                    }else{
                        break;
                    }
                    
                }
                if(flag*1<1){
                alert("Please input atleast one item details");
                
                return false;
                }


            }
            function set_correspondence(x){
                var correspondence_count_ajax=document.getElementById("correspondence_count_ajax").value;  
            
             var h=0;
                //`ccm_id`, `client_id`, `person_name`, `person_mobile`SELECT * FROM `client_correspondence_master` WHERE 1
                var ccm_id=x.value;
           
                while(h*1<correspondence_count_ajax*1)
                {
                    h++;
                    var ccm_id1=document.getElementById("ccm_id_mini_ajax"+h).value;
                    var person_mobile_mini_ajax1=document.getElementById("person_mobile_mini_ajax"+h).value;
                    if(ccm_id==ccm_id1)
                        {
                            document.getElementById("person_mobile").value=person_mobile_mini_ajax1;
                        }
                    }
                }





    </script>
</head>

<body class="fixed-navbar">


    <div class="page-wrapper">

<!-- Nav header side =========================================-->
            <?php include 'header.php'; ?>
<!-- Nav header side =========================================-->


<!--=====================================-->
        <div class="content-wrapper">
<!--=====================================-->




<!--=========== START PAGE CONTENT======================================================================-->

            <div class="row pt-2 text-center" style="background-color:#00a7f3; color:#fff; font-width:700;">
                <div class="col-lg-12">
                   <h4>ENQUIRY INPUT FORM</h4>
                </div>
            </div>



            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-md-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <div class="ibox-title" style="color:red;">ENQUIRY INPUT FORM </div>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            <div class="ibox-body">

                                <form action="" method="post">
                                    <input type="hidden" id="enq_id" name="enq_id" readonly="readonly" value=""/>
                                    

                                    <div class="row">
                                        <div class="col-sm-3 form-group">
                                            <label> Enquiry Subject <span style="color:red;"></label>
                                            <input class="form-control" type="text" name="enq_subject" id="enq_subject" value="" required>
                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> Enquiry No. <span style="color:red;"></label>
                                            <input class="form-control" type="text" name="enq_no" id="enq_no" value="" required>
                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label>Client Name <span class="text-danger"><span>*</span></label>
                                            <select class="form-control" name="client_id" id="client_id" onChange="set_data(this);" required>
                                            <option value="">Choose</option>

                                                <option value="">Susmita Das</option>
                                                <option value="">Sumit Chowdhary</option>
                                                <option value="">Ram</option>

                                            </select>
                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> Contact No. <span style="color:red;"></span></label>

                                            <input class="form-control" type="text" name="contact_no" id="contact_no" value="">
                                        </div>
                                        <div class="col-sm-6 form-group">
                                            <label> Address <span style="color:red;"></span></label>
                                          
                                            <input class="form-control" name="address" id="address" cols="30" rows="2" value="">
                                            
                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> Email Id <span style="color:red;"></span></label>

                                             <input class="form-control" type="text" name="email_id" id="email_id" value="">

                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> GST No. <span style="color:red;"></span></label>

                                            <input class="form-control" type="text" name="gst_no" id="gst_no" value="">

                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> Enquiry Date <span style="color:red;"><span>*</span></label>
                                            <input class="form-control" type="date" name="enq_date" id="enq_date" value="">
                                        </div>
                                        <div class="col-sm-3 form-group">
                                            <label> Salesman <span class="text-danger"><span>*</span></label>
                                            
                                            <select class="form-control" name="salesman_id" id="salesman_id">
                                                <option value="">Choose</option>
                                                <option value="">Ram</option>
                                            </select>
                        
                                        </div>
  
                                        <div class="col-lg-3">
                                            <label>Correspondence By Person</label>

                                              <select class="form-control" name="" required>
                                                <option value="" selected disabled="">Choose</option>
                                                <option value="">Ram</option>
                                                <option value="">Lisa</option>
                                                <option value="">Jon</option>
                                              </select>  
                                          
                                        </div>
                                        <div class="col-lg-3">
                                                <label>Contact No.</label>
                                                <input class="form-control" name="person_mobile" id="person_mobile" value="">
                                               
                                        </div>
                                        <div class="col-lg-12">
                                                <div class="row pt-2 " style="color:red; font-width:700;">
                                                    <div class="col-lg-12">
                                                    <h4 class="text-uppercase">Requirement (atleast one item to be filled) * :-</h4>
                                                    </div>
                                                </div>
                                        </div>
                                       
                                            <table id="dynamic_table" class="table" style="table-layout:fixed;">
                                                <thead>
                                                    <tr>
                                                        <th width="200px">ITEM NAME</th>
                                                        <th width="550px">DESCRIPTION</th>
                                                        <th width="100px">QUANTITY</th>
                                                        <th width="200px">UNIT</th>
                                                        <th>ACTION</th>                               
                                                    </tr>
                                                </thead>
                                                <tbody>

                                                        <tr>
                                                            <td>
                                                                <select class="form-control" id="" name="item_name[]">
                                                                    <option value="" selected disabled="">Choose</option>
                                                                    <option value="">Item 1</option>
                                                                    <option value="">Item 2</option>
                                                                    <option value="">Item 3</option>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <textarea class="form-control" name="description[]" id="" cols="30" rows="1"></textarea>
                                                            </td>
                                                            <td>
                                                                <input type="number" class="form-control" name="qty[]">
                                                            </td>
                                                            <td>
                                                                <select class="form-control" name="unit[]" id="">
                                                                    <option value="" selected disabled="">Choose</option>
                                                                    <option value="">Cm</option>
                                                                    <option value="">Gram</option>
                                                                    <option value="">KG</option>
                                                                </select>
                                                            </td>
                                                            <td>
                                                                <button type="button" class="btn btn-primary" class="add_btn" id="add_btn">Add</button>
                                                            </td>
                                                        </tr>


                                                  


                                                

                                            
                                                </tbody>
                                            </table>
                                       
                                            

                                    </div>
                                        
                                              
                                    <div class="row">
                                        <div class="col-sm-3 form-group">
                                          <button class="btn btn-success" type="submit" name="submit">Submit</button>
                                        </div>
                                    </div>   
                                </form> 
                                
                                
                            </div>
                        </div>               
                    </div>   
                </div>     
            </div>          



                                    
            <div class="page-content fade-in-up">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="ibox">
                            <div class="ibox-head">
                                <u style="color:red;"><div style="color:red;" class="ibox-title">ENQUERY DETAILS :- </div></u>
                                <div class="ibox-tools">
                                    <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                                </div>
                            </div>
                            
                            <div class="ibox-body">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <!--`enq_id`, `client_id`, `ccm_id`, `enq_no`, `enq_subject`, `enq_date`, `salesman_id`, 
                                        `flag`SELECT * FROM `enquery` WHERE 1-->
                                        <!--`id`, `client_id`, `item_id`, `description`, `qty_requirement`SELECT * FROM `enq_item_details` WHERE 1-->
                                        <tr>
                                            <th width="300px">ENQUIRY NO.</th>
                                            <th>ENQUIRY SUBJECT</th>
                                            <th>CLIENT</th>
                                            <th>CORRESPONDENCE</th>
                                            <th>ENQUERY DATE</th>
                                            <th>SALESMAN NAME</th>
                                            <th>ITEM NAME</th> 
                                            <th>DESCRIPTION</th>
                                            <th>REQUIRED QUANTITY</th> 
                                            <th>QTY. UNIT</th> 
                                            <th>ACTION</th>                               
                                        </tr>
                                    </thead>
                                    <tbody>


            

                                            <tr>
                                                <td>57575745</td>
                                                <td>Enquiry-256</td>
                                                <td>SUMITA DAS /2969868	</td>
                                                <td>SOUVIK SARKAR /9982214476</td>
                                                <td>2023-12-13</td>
                                                <td>JON DON	</td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>                                                
                                                <form method="post" action="" enctype="multipart/form-data" onsubmit="return myFunction();">          
                                                    <input type="hidden" name="" value="" />
                                                    
                                                    <td class="d-flex"><a href=""><i class="fa fa-pencil-square" aria-hidden="true" style="font-size:25px;"></i></a><button  style="border:none; color:#007bff" type="submit" name="delete"><i class="fa fa-trash" aria-hidden="true" style="font-size:25px;"></i></a></button></td>
                                                </form>   
                                            </tr>



                                               
                                            <tr>
              
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>
                                                <td></td>

                                                <td>Item_1</td>
                                                <td>Lorem ipsum dolor sit amet consectetur adipisicing elit. </td>
                                                <td>KG</td>
                                                <td>11</td>
                                             
                                            </tr>

                                 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    

                </div>
                </div>                
                <style>
                    th{
                        font-size:12px;
                    }
                    .visitors-table table tbody tr td td:last-child {
                        display: flex;
                        align-items: center;
                    }

                    .visitors-table .progress {
                        flex: 1;
                    }

                    .visitors-table .progress-parcent {
                        text-align: right;
                        margin-left: 10px;
                    }
                    .scrollmenu {
                        
                      background-color: #FFF;
                       overflow: auto;
                    
                   }
                </style>

            </div>









<!--=========== End PAGE CONTENT======================================================================-->



<!-- Nav header side =========================================-->
        <?php include 'footer.php'; ?>
<!-- Nav header side =========================================-->
<!--=====================================-->
        </div>
    </div>
<!--=====================================-->

    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- CORE PLUGINS-->
    <script src="./assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="./assets/vendors/chart.js/dist/Chart.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/jvectormap/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
    <script src="./assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js" type="text/javascript"></script>
    <script src="./assets/vendors/jvectormap/jquery-jvectormap-us-aea-en.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="assets/js/app.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="./assets/js/scripts/dashboard_1_demo.js" type="text/javascript"></script>

    <script>
        $(document).ready(function(){
            var html='<tr> <td> <select class="form-control" id="" name="item_name[]"> <option value="" selected disabled="">Choose</option> <option value="">Item 1</option> <option value="">Item 2</option> <option value="">Item 3</option> </select> </td> <td> <textarea class="form-control" name="description[]" id="" cols="30" rows="1"></textarea> </td> <td> <input type="number" class="form-control" name="qty[]"> </td> <td> <select class="form-control" name="unit[]" id=""> <option value="" selected disabled="">Choose</option> <option value="">Cm</option> <option value="">Gram</option> <option value="">KG</option> </select> </td> <td> <button type="button" class="btn btn-danger" class="remove_btn" id="remove_btn">Remove</button> </td> </tr>';
            var x = 1;
            $("#add_btn").click(function(){
                $("#dynamic_table").append(html);
            });
            $("#dynamic_table").on('click','#remove_btn',function(){
                $(this).closest('tr').remove();
				calculate_total_commodity(this);
				
            });
        });
    </script>
</body>

</html>