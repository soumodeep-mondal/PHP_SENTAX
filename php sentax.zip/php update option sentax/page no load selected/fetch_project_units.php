<?php
include_once 'db/conn.php';

if (isset($_POST['project_id'])) {
    $project_id = $_POST['project_id'];
    $selected_unit_id = isset($_POST['selected_unit_id']) ? $_POST['selected_unit_id'] : '';
    $query2 = mysqli_query($conn, "SELECT * FROM project_unit_master WHERE project_id='$project_id'");
    $row_count = mysqli_num_rows($query2);

    if ($row_count > 0) {
        echo '<option value="">Select Project Unit</option>';
        while ($row_project_unit = mysqli_fetch_array($query2)) {
            $selected = ($row_project_unit['project_unit_id'] == $selected_unit_id) ? 'selected' : '';
            echo '<option value="' . $row_project_unit['project_unit_id'] . '" ' . $selected . '>' . $row_project_unit['project_unit_name'] . '</option>';
        }
    } else {
        echo '<option value="">No Project Unit Found</option>';
    }
}
?>
