<form action="" method="post">
    <div class="row">
        <div class="col-sm-2 form-group">
            <label>Form Date</label>
            <input class="form-control" type="date" name="form_date" id="form_date" value="<?php if (isset($_POST['form_date'])) { echo $_POST['form_date']; } ?>">
        </div>
        <div class="col-sm-2 form-group">
            <label>To Date</label>
            <input class="form-control" type="date" name="to_date" id="to_date" value="<?php if (isset($_POST['to_date'])) { echo $_POST['to_date']; } ?>">
        </div>
        <div class="col-sm-3 form-group">
            <label>Project Name <span class="text-danger">*</span></label>
            <select class="form-control" name="project_id" id="project_id" onchange="fetchProjectUnits();" required>
                <option value="">Select Project</option>
                <?php
                $query = mysqli_query($conn, "SELECT * FROM project_master");
                while ($row_project = mysqli_fetch_array($query)) { ?>
                    <option value="<?php echo $row_project['project_id']; ?>" <?php if (isset($_POST['project_id']) && $row_project['project_id'] == $_POST['project_id']) echo 'selected'; ?>>
                        <?php echo $row_project['project_name']; ?>
                    </option>
                <?php } ?>
            </select>
        </div>
        <div class="col-sm-3 form-group">
            <label>Project Unit Name <span class="text-danger">*</span></label>
            <select class="form-control" name="project_unit_id" id="project_unit_id" required>
                <option value="">Select Project Unit</option>
                <!-- Options will be populated by AJAX -->
            </select>
        </div>
        <div class="col-sm-2 form-group mt-4 pt-2">
            <button class="btn btn-success" type="submit" name="submit">Search</button>
            <button class="btn btn-warning" type="submit" name="submit">Print</button>
        </div>
    </div>
</form>

<script>
function fetchProjectUnits() {
    var projectId = $('#project_id').val();
    var selectedUnitId = "<?php echo isset($_POST['project_unit_id']) ? $_POST['project_unit_id'] : ''; ?>";
    $.ajax({
        url: 'fetch_project_units.php',
        type: 'POST',
        data: {project_id: projectId, selected_unit_id: selectedUnitId},
        success: function(response) {
            $('#project_unit_id').html(response);
        }
    });
}

// Trigger the function on page load if project_id is set
$(document).ready(function() {
    if ($('#project_id').val() !== '') {
        fetchProjectUnits();
    }
});
</script>
