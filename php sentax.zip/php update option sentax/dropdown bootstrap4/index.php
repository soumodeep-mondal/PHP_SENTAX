
<form action="test2.php" method="post">
        <div class="col-lg-4 form-group">
            <label style=""> Material <span class="text-danger">*</span></label>
            <select class="selectpicker form-control" name="raw_material_id" id="raw_material_select" data-live-search="true">
                <option value="" selected disabled="none">Choose Name</option>
                <?php
                $sql_ctgy = "SELECT * FROM `raw_material_master` WHERE 1";
                $query_ctgy = mysqli_query($conn, $sql_ctgy);
                while ($ctgy = mysqli_fetch_array($query_ctgy)) { ?>
                    <option value="<?php echo $ctgy['raw_material_id']; ?>" <?php if (isset($_REQUEST['xedit'])) if ($ctgy['raw_material_id'] == $raw_material_id) echo 'selected'; ?>><?php echo $ctgy['raw_material_name']; ?></option>
                <?php
                }
                ?>
            </select>
        </div>
        <button type="submit">Submit</button>
    </form>

<!--     Add Script css link
<link href="./assets/vendors/bootstrap/dist/css/bootstrap-select.css" rel="stylesheet" />
<script src="./assets/vendors/bootstrap/dist/js/bootstrap-select.js" type="text/javascript"></script> -->









<!-- ==============Dynamick Dropdown add ====================== -->
<!-- $('.selectpicker').selectpicker(); // Initialize selectpicker

        $(document).ready(function(){
            var html='<tr> <td class="col-md-2"> <select class="selectpicker form-control" name="raw_material_id[]" id="raw_material_id" data-live-search="true" required> <option value="" selected disabled="none">Choose Item</option> <?php /*`id`, `purchase_id`, `raw_material_id`, `raw_matarial_quantity`, `raw_matarial_desc` SELECT * FROM `direct_purchase_order_details` WHERE 1*/ $query1=mysqli_query($conn,"select * from raw_material_master order by raw_material_name"); while($fetch1=mysqli_fetch_array($query1)) {?> <option value="<?php echo $fetch1['raw_material_id'];?>"><?php echo $fetch1['raw_material_name'];?></option> <?php } ?> </select> </td> <td class="col-md-4"> <textarea class="form-control material_decription" name="raw_matarial_desc[]" id="" cols="30" rows="1" onKeyUp="convert_data_to_upper(this);"></textarea> </td> <td class="col-md-1"> <input type="number" class="form-control"  name="raw_matarial_quantity[]" required> </td> <td class="col-md-1"> <input type="number" class="form-control"  name="raw_matarial_rate[]" required> </td> <td class="col-md-1"> <input type="number" class="form-control"  name="raw_matarial_amount[]" required> </td>  <td class="col-md-1"> <button type="button" id="remove_item_btn"  class="btn btn-danger">Remove</button> </td> </tr>  <tr><td></td> </tr><tr><td></td> </tr> <tr><td></td> </tr>';
            var x = 1;
            $("#add_item_btn").click(function(){
                $("#add_item_table").append(html);
                $('.selectpicker').selectpicker(); // Initialize selectpicker
            });
            $("#add_item_table").on('click','#remove_item_btn',function(){
                $(this).closest('tr').remove();
                calculate_total_commodity(this);
                
            });
        }); -->