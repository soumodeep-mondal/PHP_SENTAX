<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Create a PHPMailer instance
$mail = new PHPMailer(true);

try {
    // SMTP configuration for Gmail
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'check.formsubmission@gmail.com';
    $mail->Password = 'mehzqzvfwwggxpzo';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Sender and recipient settings
    $mail->setFrom('check.formsubmission@gmail.com', 'Your Name');
    $mail->addAddress('soumodeepmondal20@gmail.com', 'Recipient Name');

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Email with Image';
    $mail->Body = '
    

    <div>
        <div>
            <div>
                <div style="background-color:rgb(230, 178, 7);margin-top: 20px ;">
                    <div>
                        <div style="text-align: center;padding-top: 30px;">
                            <img src="cid:image1" width="80%" alt="">
                        </div>
                    </div>
                    
                    <div>
                        <div class="p-3" style="padding: 30px;">
                            <div class="text-left mb-3" style="border-top: 5px solid #ffffff;color:#fff; background-color: #66ad09;;">
                                <div style="padding: 30px;">
                                    <h4>Hi Soumodeep,</h4>
                                    <h4 class="pt-5">
                                        Your package will be delivered between 7:00AM and 10:00PM by our Amazon Delivery Agent (Phone: +913366764444  PIN 6843).
                                    </h4>

                                    <div style="text-align: center;">
                                        <button style="background-color: rgb(230, 178, 7); border:none; width: 80%;padding: 20px; font-size: 14px;font-weight: 900;">View Your Order</button>
                                    </div>
                                    <h5>
                                        This email was sent from an email address that cant receive emails. Please dont reply to this email.
                                    </h5>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>    
</div>


    
    ';


    // Attach the image
    $imagePath = 'image.jpg'; //path/to/your/image.jpg // Replace with your image file path
    $mail->addEmbeddedImage($imagePath, 'image1');

    // Send the email
    $mail->send();
    echo 'Email with image has been sent!';
} catch (Exception $e) {
    echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>


