<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Check if a file is uploaded
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] == UPLOAD_ERR_OK)
{
    // Get file details
    $file_name = $_FILES['attachment']['name'];
    $file_tmp = $_FILES['attachment']['tmp_name'];

    // Create a new PHPMailer instance
    $mail = new PHPMailer(true);

    try
    {
        // SMTP configuration (change these settings accordingly)
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'check.formsubmission@gmail.com';
        $mail->Password = 'mehzqzvfwwggxpzo';
        $mail->SMTPSecure = 'ssl';
        $mail->Port = 465;

        // Sender and recipient
        $mail->setFrom('check.formsubmission@gmail.com','Website Enquiry Form');
        $mail->addAddress('check.formsubmission@gmail.com');

        // Attach the file
        $mail->addAttachment($file_tmp, $file_name);
        $mail->isHTML(true);
        // Email content
        $mail->Subject = $_POST["name"];

        $mail->Body = "<b>Name :</b> ".$_POST["name"]."<br>".
                      "<b>Email :</b> ".$_POST["email"]."<br>".
                      "<b>Mobile No. :</b> ".$_POST["mob"];

        // Send the email
        if($mail->send()){
            echo "<script>alert('Form submit sucessfully owner will be contact soon...')</script>";
            echo "<script>location.href='carrier.html'</script>";
          }

        echo 'Email sent successfully!';
    } catch (Exception $e) {
        echo 'Email could not be sent. Error: ', $mail->ErrorInfo;
    }
}   
else
{
    echo "<script>alert('Error please try again')</script>";
}
?>
