<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

// Create a PHPMailer instance
$mail = new PHPMailer(true);

try {
    // SMTP configuration for Gmail
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = 'check.formsubmission@gmail.com';
    $mail->Password = 'mehzqzvfwwggxpzo';
    $mail->SMTPSecure = 'tls';
    $mail->Port = 587;

    // Sender and recipient settings
    $mail->setFrom('check.formsubmission@gmail.com', 'Your Name');
    $mail->addAddress('soumodeepmondal20@gmail.com', 'Recipient Name');

    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Email with Image';
    $mail->Body = '<h1>Hello!</h1><p>This email contains an image:<br><img src="cid:image1" alt="Image"></p>';
    $mail->AltBody = 'Hello! This email contains an image.';

    // Attach the image
    $imagePath = 'image.jpg'; //path/to/your/image.jpg // Replace with your image file path
    $mail->addEmbeddedImage($imagePath, 'image1');

    // Send the email
    $mail->send();
    echo 'Email with image has been sent!';
} catch (Exception $e) {
    echo "Email could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
