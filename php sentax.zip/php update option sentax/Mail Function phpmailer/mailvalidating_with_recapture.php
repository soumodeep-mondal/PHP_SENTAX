
<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';

$msg="";

if(isset($_POST['send'])){

    if(isset($_POST['g-recaptcha-response'])){
      $captcha=$_POST['g-recaptcha-response'];
    }
    if(!$captcha){
      echo '<h2>Please check the the captcha form.</h2>';
      exit;
    }
    $secretKey = "6LcrRhUpAAAAAGM0qmrMDVrXSA5LbgAtZjtTJXlP"; // Add secure Key
    $ip = $_SERVER['REMOTE_ADDR'];
    // post request to server
    $url = 'https://www.google.com/recaptcha/api/siteverify?secret=' . urlencode($secretKey) .  '&response=' . urlencode($captcha);
    $response = file_get_contents($url);
    $responseKeys = json_decode($response,true);
    // should return JSON with success as true
    if($responseKeys["success"]) {

      // Send SMTP mail start
            
      $mail = new PHPMailer(true);
      $mail->isSMTP();
      $mail->Host = 'smtp.gmail.com';
      $mail->SMTPAuth = true;
      //$mail->Username = 'chariveti@gmail.com';
      //$mail->Password = 'fimawfqblwzgzvxt';
      $mail->Username = 'soumodeep.official20@gmail.com';
      $mail->Password = 'lxefebdbhtvujxqc';
      $mail->SMTPSecure = 'ssl';
      $mail->Port = 465;
                      
      $mail->setFrom('soumodeep.official20@gmail.com','Website Enquiry Form');
      $mail->addAddress('soumodeep.official20@gmail.com');
      $mail->isHTML(true);
      $mail->Subject = $_POST["subject"];
      $mail->Body = "<b>Name :</b> ".$_POST["name"]."<br>".
                    "<b>Email :</b> ".$_POST["email"]."<br>".
                    "<b>Subject :</b> ".$_POST["subject"]."<br>".
                    "<b>Message :</b> ".$_POST["message"];
            
        if($mail->send()){
          $msg="Thanks for posting comment";
        }
        else{
          $msg="Database Error";
        }
      // Send SMTP mail End   

    } else {
            echo '<h2>You are spammer !</h2>';
    }
}
?>
<h2><?php echo $msg;?></h2>
<a href="contact.html"><button>Go Back</button></a>
<!-- ////////////End///////////////////////////////////////////////-->







<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
</head>
<body>
                    <form action="mailvalidating.php" method="POST">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  name="name" id="name" placeholder="Your Name">
                                    <label for="name">Your Name</label>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-floating">
                                    <input type="email" class="form-control" name="email" id="email"  placeholder="Your Email">
                                    <label for="email">Your Email</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <input type="text" class="form-control"  name="subject" id="subject"  placeholder="Subject">
                                    <label for="subject">Subject</label>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="form-floating">
                                    <textarea class="form-control"   name="message" id="message" placeholder="Leave a message here" style="height: 200px"></textarea>
                                    <label for="message">Message</label>
                                </div>
                            </div>
                            <!-- Google recaptcha Section -->
                             <div class="g-recaptcha" data-sitekey="6LcrRhUpAAAAACa_rRi60f91hzhMX4U0e_gBsdLN"></div>
                            <div class="col-12 text-center">
                                <button class="btn btn-primary rounded-pill py-3 px-5" type="submit"  name="send">Send Message</button>
                            </div>
                        </div>
                    </form>
</body>
</html>