<?php 
include_once("../conn/db.php");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
require 'phpmailer/src/Exception.php';
require 'phpmailer/src/PHPMailer.php';
require 'phpmailer/src/SMTP.php';




if(isset($_POST['forget_password']))
{
    //`userid`, `password`, `verify_otp`SELECT * FROM `admin` WHERE 1
    $email=trim($_POST['email']);
    $genarate_otp= random_int(100000, 999999);

     
    $checkVerifyQuery = "SELECT * FROM admin WHERE email = '$email'";
    $result = $con->query($checkVerifyQuery);

    if ($result->num_rows > 0) {

        $sql="SELECT * FROM admin WHERE email='$email'";
        $query=mysqli_query($con,$sql);
        if($r=mysqli_fetch_array($query))
        {

            
            $query=mysqli_query($con,"UPDATE admin set verify_otp='$genarate_otp' where email='$email'");

            if($query){

                $mail = new PHPMailer(true);
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'check.formsubmission@gmail.com';
                $mail->Password = 'mehzqzvfwwggxpzo';
                $mail->SMTPSecure = 'ssl';
                $mail->Port = 465;
              
                $mail->setFrom($email,'SDBS Confirmation Code');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = "SDBS Send a confirmation code" ;
                $mail->Body = "<br> Your Confirmation Code is: </b>".$genarate_otp;
              
              
                if($mail->send()){
                  
                    header("Location:encrypted_forget_verify_otp.php?email=".$email);
                }
                else{
                  echo "<script>alert('Error please try again')</script>";
                }
            }
            else {
                echo "Error: " . $query . "<br>" . $con->error;
            }
        }
    } 
    else {
        echo '<script>alert("User Id No Did not Match ! Please check your user Id")</script>';
    }       
                

}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Sara Bangla Daba Sangstha - Forget Password</title>
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="description" content="Smart Fix - Computer Repair Store HTML5 Template">
    <meta name="author" content="xenioushk">
    <link rel="shortcut icon" href="images/favicon.png" />
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/animate.css" rel="stylesheet" type="text/css" />
    <link href="css/styles.css" rel="stylesheet" type="text/css" />
    <link href="css/admin.css" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css2?family=Josefin+Sans:ital,wght@0,200;0,300;0,400;0,500;0,600;0,700;1,200;1,300;1,400;1,500;1,600;1,700&display=swap" rel="stylesheet">


<body>

    <!--  HEADER -->
    <header class="main-header-2 clearfix" data-sticky_header="true">
        <section class="header-wrapper navgiation-wrapper">

            <!-- Topbar start -->
            <div class="main-top-header clearfix">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 text-center">
                            <div class="top-bar-link">
                                <h4 class="mb-0 text-white">Admin : Sara Bangla Daba Sangstha</h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end header-top -->

        </section>
    </header>
    <!-- end main-header -->



    <!-- Log In section -->
    <section class="section-content-block admin-login">
        <div class="log-in">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-12 text-center">
                        <h2 class="heading-section">Sara Bangla Daba Sangstha Admin Panel</h2>
                    </div>
                </div>
                <div class="row justify-content-center align-items-center">
                    <div class="col-lg-6 col-md-9">
                        <div class="login-wrap py-5">
                            <h3 class="text-center">FORGET PASSWORD</h3>
                            <p class="text-center"> Forget password by entering the information below</p>
                            <form action="" class="login-form pt-3" method="post" onsubmit="return validate();">
                                <div class="form-group">
                                    <div class="icon d-flex align-items-center justify-content-center"><span class="fa fa-user"></span></div>
                                    <input type="text" name="email" id="email" class="form-control" placeholder="Enter User Id" required>
                                </div>
                                <div class="form-group  mb-5">
                                    <p class="text-right"><a href="index.php">Back to Login</a> </p>
                                    
                                </div>

                                <div class="form-group mt-5">
                                    <button type="submit" name="forget_password" class="btn form-control btn-primary rounded submit px-3">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Log In section End -->



    <!-- START FOOTER 05 -->
    <footer class="section-pure-black-bg">
        <section class="footer-contents">
            <div class="container">
                <div class="row clearfix">
                    <div class="col-md-12 col-sm-12 clearfix">
                        <p class="copyright-text text-center"> Developed by <a href="http://skcinfotech.in/" target="_blank"> SKC Infotech</a>. Mobile : <a href="tel:+919830048230">+91 98300 48230</a> / <a href="tel:+919674635687">+91 96746 35687</a>; Email ID : <a href="mailto:manager.skcinfotech@gmail.com">manager.skcinfotech@gmail.com</a></p>
                    </div>
                </div>
            </div>
        </section>
    </footer>
    <!-- Footer End -->



    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/wow.min.js"></script>
    <script src="js/custom-scripts.js"></script>
</body>

</html>