<?php
session_start();

// Function to generate a random string
function generateRandomString($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ%@#!';
    $charLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charLength - 1)];
    }
    return $randomString;
}

// Set the path to the font file
$fontFile = 'font/arial.ttf'; // Change this to the appropriate font file path

// Generate a random CAPTCHA string
$captchaString = generateRandomString();
$_SESSION['captcha'] = $captchaString;

// Create an image with the CAPTCHA string
$image = imagecreatetruecolor(150, 50);
$bgColor = imagecolorallocate($image, 255, 255, 255);
$textColor = imagecolorallocate($image, 0, 0, 0);
imagefilledrectangle($image, 0, 0, 150, 50, $bgColor);
imagettftext($image, 20, 0, 10, 35, $textColor, $fontFile, $captchaString); // Use $fontFile here

// Output the image
header('Content-type: image/png');
imagepng($image);
imagedestroy($image);
?>
