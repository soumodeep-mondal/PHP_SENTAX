<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if the CAPTCHA input matches the stored CAPTCHA string
    if (isset($_SESSION['captcha']) && !empty($_SESSION['captcha'])) {
        $userInput = $_POST['captcha'];
        $captchaString = $_SESSION['captcha'];

        if (strcasecmp($userInput, $captchaString) == 0) {
            // CAPTCHA verification successful
            echo "CAPTCHA verification successful!";
        } else {
            // CAPTCHA verification failed
            echo "CAPTCHA verification failed. Please try again.";
        }
    } else {
        // CAPTCHA session not found
        echo "CAPTCHA session not found.";
    }
    exit; // Stop execution to prevent further rendering of the HTML form
}
?>
