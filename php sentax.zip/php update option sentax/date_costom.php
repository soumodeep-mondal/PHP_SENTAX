<?php
//Thu, Dec 21th 23 
$date = date("D, M jS H");
echo $date;
?>