<?php
$conn=new mysqli('localhost','root','','jh_express_db') or die('connection not sucessful'.mysqli_connect_errors());
?>