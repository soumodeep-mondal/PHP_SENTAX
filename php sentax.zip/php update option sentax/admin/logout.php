<?php



if(isset($_SESSION['userid'])){
    session_unset();
    session_destroy();
    echo header("location:index.php");
}
else{
    echo header("location:index.php");
}


?>